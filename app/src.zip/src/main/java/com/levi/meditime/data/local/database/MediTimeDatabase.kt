package com.levi.meditime.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.levi.meditime.data.local.converters.Converters
import com.levi.meditime.data.local.dao.MedicineDao
import com.levi.meditime.data.local.entity.EmergencyContactEntity
import com.levi.meditime.data.local.entity.FamilyMemberEntity
import com.levi.meditime.data.local.entity.HistoryEntity
import com.levi.meditime.data.local.entity.MedicineEntity
import com.levi.meditime.data.local.entity.ReminderEntity
import com.levi.meditime.data.local.entity.UserEntity
import com.levi.meditime.data.local.entity.CaretakerEntity
import com.levi.meditime.data.local.entity.SymptomEntity
import com.levi.meditime.data.local.entity.PrescriptionEntity
import com.levi.meditime.data.local.entity.AppointmentEntity
import com.levi.meditime.data.local.entity.UserProfileEntity

@Database(
    entities = [
        MedicineEntity::class,
        ReminderEntity::class,
        HistoryEntity::class,
        FamilyMemberEntity::class,
        EmergencyContactEntity::class,
        UserEntity::class,
        CaretakerEntity::class,
        SymptomEntity::class,
        PrescriptionEntity::class,
        AppointmentEntity::class,
        UserProfileEntity::class
    ],
    version = 10,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class MediTimeDatabase : RoomDatabase() {
    abstract fun medicineDao(): MedicineDao
}
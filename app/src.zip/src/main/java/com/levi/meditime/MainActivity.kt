package com.levi.meditime

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.levi.meditime.core.util.LocaleHelper
import com.levi.meditime.datastore.ThemeMode
import com.levi.meditime.datastore.ThemePreferences
import com.levi.meditime.domain.repository.AuthRepository
import com.levi.meditime.presentation.navigation.NavGraph
import com.levi.meditime.presentation.navigation.Screen
import com.levi.meditime.presentation.security.AppLockScreen
import com.levi.meditime.presentation.theme.FloatingBottomNavigation

import com.levi.meditime.presentation.theme.MediTimeMedicineReminderTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@AndroidEntryPoint
class MainActivity : androidx.fragment.app.FragmentActivity() {

    private val exceptionHandler = kotlinx.coroutines.CoroutineExceptionHandler { _, throwable ->
        android.util.Log.e("MediTime_Crash", "MainActivity caught exception: ${throwable.localizedMessage}", throwable)
    }

    @Inject
    lateinit var authRepository: AuthRepository
    
    @Inject
    lateinit var themePreferences: ThemePreferences

    @Inject
    lateinit var screenshotSecurityManager: com.levi.meditime.manager.ScreenshotSecurityManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val userSettings by themePreferences.userSettings.collectAsState(initial = null)
            val themeMode = userSettings?.themeMode ?: ThemeMode.SYSTEM
            val currentLang = userSettings?.language ?: "en"
            val allowScreenshots = userSettings?.allowScreenshots ?: true
            val accessibilityMode = userSettings?.accessibilityMode ?: false

            LaunchedEffect(currentLang) {
                // PRD 1.3: Let AppCompatDelegate handle recreation. 
                // Only call if there's an actual change to avoid loops.
                if (androidx.appcompat.app.AppCompatDelegate.getApplicationLocales().toLanguageTags() != currentLang) {
                    LocaleHelper.applyLocale(currentLang)
                }
            }

            Crossfade(
                targetState = themeMode,
                animationSpec = tween(durationMillis = 600),
                label = "themeSwitch"
            ) { mode: ThemeMode ->
                MediTimeMedicineReminderTheme(
                    darkTheme = when (mode) {
                        ThemeMode.LIGHT -> false
                        ThemeMode.DARK -> true
                        ThemeMode.SYSTEM -> androidx.compose.foundation.isSystemInDarkTheme()
                    },
                    accessibilityMode = accessibilityMode
                ) {
                    val user by authRepository.currentUser.collectAsState(initial = null)
                    val navController = rememberNavController()
                    
                    // Global Session Revocation Listener
                    LaunchedEffect(user) {
                        user?.let {
                            val uid = it.uid
                            val securityRef = FirebaseDatabase.getInstance().getReference("users").child(uid).child("security")
                            
                            securityRef.get().addOnSuccessListener { snapshot ->
                                val lastLogin = snapshot.child("lastLoginTimestamp").getValue(Long::class.java) ?: 0L
                                val revocationTime = snapshot.child("revocationTimestamp").getValue(Long::class.java) ?: 0L
                                
                                if (revocationTime > lastLogin) {
                                    lifecycleScope.launch(exceptionHandler) {
                                        authRepository.logout()
                                        navController.navigate(Screen.Login.route) {
                                            popUpTo(0) { inclusive = true }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = navBackStackEntry?.destination?.route

                    LaunchedEffect(currentRoute, allowScreenshots) {
                        val shouldProtect = screenshotSecurityManager.shouldProtectScreen(currentRoute, allowScreenshots)
                        screenshotSecurityManager.setScreenshotEnabled(this@MainActivity, !shouldProtect)
                    }

                    // PRD 1.3: Use rememberSaveable to persist unlock state during configuration changes (like language switch)
                    var isUnlocked by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }
                    
                    val lifecycleOwner = LocalLifecycleOwner.current
                    DisposableEffect(lifecycleOwner) {
                        val observer = LifecycleEventObserver { _, event ->
                            if (event == Lifecycle.Event.ON_STOP) {
                                isUnlocked = false
                            }
                        }
                        lifecycleOwner.lifecycle.addObserver(observer)
                        onDispose {
                            lifecycleOwner.lifecycle.removeObserver(observer)
                        }
                    }

                    val appLockEnabled = userSettings?.appLockEnabled ?: false
                    
                    if (appLockEnabled && !isUnlocked) {
                        AppLockScreen(
                            onUnlockSuccess = { isUnlocked = true },
                            securityManager = screenshotSecurityManager
                        )
                    } else {
                        val bottomNavRoutes = listOf(
                            Screen.Dashboard.route,
                            Screen.Medicines.route,
                            Screen.Reports.route,
                            Screen.Family.route,
                            Screen.Account.route
                        )

                        Scaffold(
                            modifier = Modifier.fillMaxSize(),
                            bottomBar = {
                                if (user != null && currentRoute in bottomNavRoutes) {
                                    FloatingBottomNavigation(
                                        currentRoute = currentRoute,
                                        onNavigate = { route ->
                                            navController.navigate(route) {
                                                popUpTo(Screen.Dashboard.route) { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        },
                                        onAddMedicine = {
                                            navController.navigate(Screen.AddMedicine.route)
                                        },
                                        onScanPrescription = {
                                            navController.navigate(Screen.PrescriptionScanner.route)
                                        },
                                        onAddAppointment = {
                                            navController.navigate(Screen.Appointments.route)
                                        },
                                        onAddFamily = {
                                            navController.navigate(Screen.AddFamilyMember.route)
                                        }
                                    )
                                }
                            }
                        ) { padding ->
                            val startDestination =
                                if (user != null) Screen.Dashboard.route else Screen.Login.route
                            Surface(modifier = Modifier.padding(padding)) {
                                NavGraph(navController = navController, startDestination = startDestination)
                            }
                        }
                    }
                }
            }
        }
    }
}

package com.levi.meditime.presentation.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.levi.meditime.domain.model.DoseStatus
import com.levi.meditime.domain.repository.MedicineRepository
import com.levi.meditime.domain.repository.AuthRepository
import com.levi.meditime.manager.PdfManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

enum class TimePeriod { WEEKLY, MONTHLY, YEARLY }

data class ReportState(
    val selectedPeriod: TimePeriod = TimePeriod.WEEKLY,
    val adherence: Int = 0,
    val takenCount: Int = 0,
    val missedCount: Int = 0,
    val refillCount: Int = 0,
    val streak: Int = 0,
    val isLoading: Boolean = false,
    val reportFile: File? = null,
    val message: String? = null
)

@HiltViewModel
class ReportViewModel @Inject constructor(
    private val repository: MedicineRepository,
    private val authRepository: AuthRepository,
    private val pdfManager: PdfManager
) : ViewModel() {

    private val _state = MutableStateFlow(ReportState())
    val state = _state.asStateFlow()

    init {
        loadReportData()
    }

    fun setPeriod(period: TimePeriod) {
        _state.update { it.copy(selectedPeriod = period) }
        loadReportData()
    }

    fun exportReport() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            val user = authRepository.currentUser.first()
            val history = repository.getAllHistory().first()
            val medicines = repository.getAllMedicines().first()
            
            val file = pdfManager.generateFullReport(
                userName = user?.name ?: "User",
                adherence = _state.value.adherence,
                history = history,
                medicines = medicines,
                fileName = "MediTime_Report_${System.currentTimeMillis()}"
            )
            
            _state.update { 
                it.copy(
                    isLoading = false,
                    reportFile = file,
                    message = if (file != null) "Report exported to Downloads/MediTime" else "Failed to export report"
                )
            }
        }
    }

    fun clearMessage() {
        _state.update { it.copy(message = null, reportFile = null) }
    }

    private fun loadReportData() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            
            repository.getAllHistory().distinctUntilChanged().collectLatest { history ->
                val taken = history.count { it.status == DoseStatus.TAKEN }
                val missed = history.count { it.status == DoseStatus.MISSED }
                val total = history.size
                
                _state.update { 
                    it.copy(
                        adherence = if (total > 0) (taken * 100) / total else 0,
                        takenCount = taken,
                        missedCount = missed,
                        refillCount = 2,
                        streak = calculateStreak(history),
                        isLoading = false
                    )
                }
            }
        }
    }

    private fun calculateStreak(history: List<com.levi.meditime.domain.model.History>): Int {
        if (history.isEmpty()) return 0
        val sorted = history.sortedByDescending { it.actionTime }
        var streak = 0
        for (item in sorted) {
            if (item.status == DoseStatus.TAKEN) streak++
            else break
        }
        return streak
    }
}

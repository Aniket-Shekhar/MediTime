package com.levi.meditime.di

import android.content.Context
import androidx.room.Room
import com.levi.meditime.data.local.database.MediTimeDatabase
import com.levi.meditime.data.local.dao.MedicineDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): MediTimeDatabase {
        System.loadLibrary("sqlcipher")
        
        // Force delete the old database to resolve the "file is not a database" error
        // caused by SQLCipher 4.5.4 vs 4.16.0 incompatibility.
        // This is a one-time operation for this migration.
        val sharedPrefs = context.getSharedPreferences("db_prefs", Context.MODE_PRIVATE)
        val isMigrated = sharedPrefs.getBoolean("sqlcipher_4_16_migrated_v3", false)
        
        if (!isMigrated) {
            context.deleteDatabase("meditime_db")
            // Also delete potential Room sidecars
            context.getDatabasePath("meditime_db-shm").delete()
            context.getDatabasePath("meditime_db-wal").delete()
            sharedPrefs.edit().putBoolean("sqlcipher_4_16_migrated_v3", true).apply()
        }

        val passphrase = "meditime_secure_key".toByteArray()
        val factory = SupportOpenHelperFactory(passphrase)

        return Room.databaseBuilder(
            context,
            MediTimeDatabase::class.java,
            "meditime_db"
        )
            .openHelperFactory(factory)
            .fallbackToDestructiveMigration(true)
            .build()
    }

    @Provides
    fun provideMedicineDao(db: MediTimeDatabase): MedicineDao {
        return db.medicineDao()
    }
}

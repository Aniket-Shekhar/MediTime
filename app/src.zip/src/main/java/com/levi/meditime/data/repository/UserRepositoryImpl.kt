package com.levi.meditime.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.FirebaseStorage
import com.levi.meditime.core.common.Resource
import com.levi.meditime.domain.model.User
import com.levi.meditime.domain.repository.UserRepository
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

import com.levi.meditime.data.local.dao.MedicineDao
import com.levi.meditime.data.mapper.toDomain
import com.levi.meditime.data.mapper.toEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

class UserRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dbRef: DatabaseReference,
    private val storage: FirebaseStorage,
    private val dao: MedicineDao
) : UserRepository {

    override suspend fun saveUser(user: User): Resource<Unit> {
        return try {
            dao.insertUser(user.toEntity())
            dbRef.child("users").child(user.uid).child("profile").setValue(user).await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Could not save user data")
        }
    }

    override fun getUser(uid: String): Flow<Resource<User>> = callbackFlow {
        trySend(Resource.Loading())
        
        // Collect local user
        val localJob = launch {
            dao.getUserById(uid).collect { entity ->
                entity?.let { trySend(Resource.Success(it.toDomain())) }
            }
        }
        
        dbRef.child("users").child(uid).child("profile")
            .get()
            .addOnSuccessListener { snapshot ->
                val user = snapshot.getValue(User::class.java)
                if (user != null) {
                    launch {
                        dao.insertUser(user.toEntity())
                    }
                    trySend(Resource.Success(user))
                } else {
                    trySend(Resource.Error("User not found"))
                }
            }
            .addOnFailureListener {
                trySend(Resource.Error(it.message ?: "An error occurred"))
            }
        awaitClose { localJob.cancel() }
    }

    override suspend fun updateUser(user: User): Resource<Unit> {
        return try {
            // Check Duplicate Phone
            if (user.phoneNumber.isNotBlank()) {
                val snapshot = dbRef.child("users").get().await()
                val duplicate = snapshot.children.any { 
                    it.key != user.uid && it.child("profile/phoneNumber").value == user.phoneNumber 
                }
                if (duplicate) return Resource.Error("Phone number already in use")
            }

            dao.insertUser(user.toEntity())
            val updates = mapOf<String, Any>(
                "users/${user.uid}/profile" to user
            )
            dbRef.updateChildren(updates).await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Could not update user")
        }
    }

    override suspend fun deleteUser(uid: String): Resource<Unit> {
        return try {
            dbRef.child("users").child(uid).removeValue().await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Could not delete user")
        }
    }

    override suspend fun uploadProfileImage(uid: String, imageUri: Uri): Resource<String> {
        return try {
            // PRD 1.2: Path changed to profile_pictures/{uid}/profile.jpg
            val ref = storage.reference.child("profile_pictures/$uid/profile.jpg")
            
            // PRD 1.2: Compression Logic
            val inputStream = context.contentResolver.openInputStream(imageUri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            val outputStream = ByteArrayOutputStream()
            
            // 70% quality for optimization
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, outputStream)
            val data = outputStream.toByteArray()
            
            // PRD 1.2: Max size validation (5MB)
            if (data.size > 5 * 1024 * 1024) {
                return Resource.Error("Image size exceeds 5MB limit.")
            }

            // PRD 1.2: Await upload before getting URL
            ref.putBytes(data).await()
            val url = ref.downloadUrl.await().toString()
            
            Resource.Success(url)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Image upload failed. Please check your internet.")
        }
    }
}

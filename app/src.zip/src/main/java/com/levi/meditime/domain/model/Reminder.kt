package com.levi.meditime.domain.model

data class Reminder(
    val id: String,
    val medicineId: String,
    val time: Long,
    val date: Long? = null,
    val repeatType: RepeatType = RepeatType.DAILY,
    val mealOption: MealOption = MealOption.NONE,
    val isActive: Boolean = true
)
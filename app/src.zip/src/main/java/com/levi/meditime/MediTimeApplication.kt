package com.levi.meditime

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject
import androidx.work.*
import com.levi.meditime.worker.AppointmentWorker
import com.levi.meditime.worker.LiveLocationWorker
import com.levi.meditime.worker.RefillReminderWorker
import java.util.concurrent.TimeUnit

import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.levi.meditime.BuildConfig

@HiltAndroidApp
class MediTimeApplication : Application(), Configuration.Provider, ImageLoaderFactory {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizePercent(0.02)
                    .build()
            }
            .crossfade(true)
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        
        FirebaseApp.initializeApp(this)
        val firebaseAppCheck = FirebaseAppCheck.getInstance()
        if (BuildConfig.DEBUG) {
            android.util.Log.d("OTP_DEBUG", "Initializing App Check Debug Provider")
            firebaseAppCheck.installAppCheckProviderFactory(
                DebugAppCheckProviderFactory.getInstance()
            )
        } else {
            firebaseAppCheck.installAppCheckProviderFactory(
                PlayIntegrityAppCheckProviderFactory.getInstance()
            )
        }

        createNotificationChannel()
        scheduleBackgroundWorkers()
    }

    private fun scheduleBackgroundWorkers() {
        val workManager = WorkManager.getInstance(this)

        // 1. Refill Reminder Worker (Every 6 hours)
        val refillRequest = PeriodicWorkRequestBuilder<RefillReminderWorker>(6, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        workManager.enqueueUniquePeriodicWork("refill_check", ExistingPeriodicWorkPolicy.KEEP, refillRequest)

        // 2. Appointment Worker (Every 1 hour)
        val appointmentRequest = PeriodicWorkRequestBuilder<AppointmentWorker>(1, TimeUnit.HOURS)
            .build()
        workManager.enqueueUniquePeriodicWork("appointment_check", ExistingPeriodicWorkPolicy.KEEP, appointmentRequest)

        // 4. Sync Worker (Every 1 hour) - PRD 1.3
        val syncRequest = PeriodicWorkRequestBuilder<com.levi.meditime.worker.SyncWorker>(1, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        workManager.enqueueUniquePeriodicWork("sync_data", ExistingPeriodicWorkPolicy.KEEP, syncRequest)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager: NotificationManager =
                getSystemService(NotificationManager::class.java)

            // 1. Medicine Reminders
            val medicineChannel = NotificationChannel(
                "medicine_reminders", 
                "Medicine Reminders", 
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for scheduled medicines"
            }
            notificationManager.createNotificationChannel(medicineChannel)

            // 2. Missed Medicine Alerts
            val missedChannel = NotificationChannel(
                "missed_medicines", 
                "Missed Medicine Alerts", 
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Urgent alerts when a dose is missed"
            }
            notificationManager.createNotificationChannel(missedChannel)

            // 3. Caretaker Alerts
            val caretakerChannel = NotificationChannel(
                "caretaker_alerts", 
                "Caretaker Alerts", 
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for caregivers"
            }
            notificationManager.createNotificationChannel(caretakerChannel)
        }
    }
}
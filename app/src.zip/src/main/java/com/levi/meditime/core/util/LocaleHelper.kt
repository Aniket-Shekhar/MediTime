package com.levi.meditime.core.util

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.util.Locale

object LocaleHelper {

    fun applyLocale(languageCode: String) {
        val appLocale: LocaleListCompat = LocaleListCompat.forLanguageTags(languageCode)
        
        // AppCompatDelegate.setApplicationLocales handles persistence and recreation automatically
        // in modern Android versions. 
        if (AppCompatDelegate.getApplicationLocales().toLanguageTags() != languageCode) {
            AppCompatDelegate.setApplicationLocales(appLocale)
        }

        // We set the default locale for immediate use in the current process 
        // (e.g. for SimpleDateFormat or string formatting)
        val locale = Locale.forLanguageTag(languageCode)
        Locale.setDefault(locale)
    }
}
